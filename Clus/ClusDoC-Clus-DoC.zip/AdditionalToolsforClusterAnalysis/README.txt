Scripts here were used for additional analysis post-processing with ClusDoC.  These were compatible with a previous version of the code and likely will not work with the current version.  

Code remains here for reference and for as examples of post-processing that can be done on these data.

The logic in these functions can be implemented using data in the the ClusterExport and ExportByPoint files (both can be imported using the readExportByPoint.m code).  