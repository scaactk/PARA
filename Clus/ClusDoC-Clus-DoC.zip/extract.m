path = "C:\Users\tjut_\Desktop\20220911\test\DBSCAN Results\Ch1\";
raw_file = load(strcat(path,'DBSCAN_Cluster_Result.mat'));
inner1 = raw_file.ClusterSmoothTable; % cell
inner2 = inner1{1,1}; % arrary

% build new array
ClusterID = [];
Number = [];
Area = [];
Circularity = [];



for i = 1:length(inner2) % traverse array
    temp = inner2(i);
    temp = temp{1,1};
    ClusterID(i) = temp.ClusterID;
    Number(i) = temp.Nb;
    Area(i) = temp.Area;
    Circularity(i) = temp.Circularity;

end


VariableNames = {'ClusterID', 'Number', 'Area', 'Circularity'};
total_table = table(ClusterID', Number', Area', Circularity', ...
    VariableNames=VariableNames);


writetable(total_table, strcat(path, 'result_ch1.csv'), Delimiter=',')
