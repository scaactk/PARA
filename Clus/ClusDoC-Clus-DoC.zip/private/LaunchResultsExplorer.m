function LaunchResultsExplorer(handles)

% Make new figure window for selecting and plotting data 

disp('Results Explorer launch');

end