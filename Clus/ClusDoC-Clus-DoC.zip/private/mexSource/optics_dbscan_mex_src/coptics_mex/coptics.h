#ifndef _COPTICS_H
#define _COPTICS_H

#include "utils.h"

struct Points
{
	array2dfloat m_points;
	int	m_i_dims;
	int 	m_i_num_points;
	//float 	m_f_core_distance;
	//float	m_f_reachability_distance;
};

#endif
